// Corre en la pagina del panel (mramos822.github.io/yape-alerts). En un
// sentido: recibe lo que el service worker reenvia desde scraper.js y lo
// mete a la pagina real (admin.html) via postMessage (el codigo de la
// pagina no puede usar chrome.runtime directo, pero si puede escuchar
// window.message). En el otro sentido: el panel avisa por window.message
// cuando se conecta/desconecta de un video para que el service worker
// abra/cierre solo la pestaña del chat popout (ver background.js).
// Un archivo abierto como file:///... no tiene un origen "real" para
// postMessage (window.location.origin da "file://", pero el navegador lo
// trata como el origen opaco "null" y rechaza el mensaje si se lo pasamos
// tal cual). Con '*' como target funciona en los dos casos (sitio publicado
// y archivo local); no es un problema de seguridad mayor aca porque el
// contenido que viajamos es texto de badges/mensajes, no algo sensible.
const targetOrigin = window.location.protocol === 'file:' ? '*' : window.location.origin;

// Avisa que la extension esta instalada apenas este script corre en la
// pagina del panel (no hace falta estar conectado a ningun chat de
// YouTube para esto: relay.js corre en cualquier carga de admin.html/
// overlay.html si la extension esta puesta, ver manifest.json). El panel
// usa esto para mostrar/ocultar la invitacion a instalarla en Home.
window.postMessage({ source: 'yape-alert-ext', type: 'ext-present' }, targetOrigin);

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg) return;
  if (msg.type === 'yt-tier') {
    window.postMessage(
      {
        source: 'yape-alert-ext',
        name: msg.name,
        tier: msg.tier,
        isMod: msg.isMod,
        isOwner: msg.isOwner,
        isMember: msg.isMember,
      },
      targetOrigin
    );
    return;
  }
  if (msg.type === 'yt-message' || msg.type === 'yt-popout-status') {
    window.postMessage({ ...msg, source: 'yape-alert-ext' }, targetOrigin);
  }
});

window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  const data = event.data;
  if (!data || data.source !== 'yape-alert-panel') return;
  chrome.runtime.sendMessage(data);
});
