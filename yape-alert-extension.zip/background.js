// Puente entre scraper.js (pestaña de YouTube) y relay.js (pestaña del
// panel): los content scripts no pueden mandarse mensajes entre si de
// forma directa, tienen que pasar por el service worker.
//
// Ademas, para que el streamer no tenga que acordarse de abrir el chat
// popout el mismo, el panel avisa aca cuando se conecta/desconecta de un
// video (ver yt-chat-connected/disconnected en admin.html) y este script
// abre/cierra esa pestaña solo. Tambien avisa el estado (abierta/cerrada)
// para que el panel muestre un indicador, y el streamer puede forzar que
// se abra con el boton "Abrir chat" por si la apertura automatica fallo.
let managedTabId = null;

function sendToPanel(msg) {
  chrome.tabs.query({ url: ['https://mramos822.github.io/*', 'file:///*'] }, (tabs) => {
    tabs.forEach((tab) => {
      chrome.tabs.sendMessage(tab.id, msg).catch(() => {
        // La pestaña del panel puede no tener el content script listo
        // todavia (recien cargando); no es un error real, se ignora.
      });
    });
  });
}

function createFreshPopout(url) {
  // active:false para que no le robe el foco a lo que el streamer este
  // mirando; solo necesitamos que la pagina exista y corra el scraper.
  return new Promise((resolve) => {
    chrome.tabs.create({ url, active: false }, (tab) => {
      managedTabId = tab.id;
      sendToPanel({ type: 'yt-popout-status', open: true });
      resolve();
    });
  });
}

function openOrFocusPopoutNow(videoId) {
  const url = `https://www.youtube.com/live_chat?v=${videoId}&is_popout=1`;
  return new Promise((resolve) => {
    chrome.tabs.query({ url: 'https://www.youtube.com/live_chat*' }, (tabs) => {
      const existing = tabs.find((t) => t.url && t.url.includes(`v=${videoId}`));
      if (existing) {
        managedTabId = existing.id;
        sendToPanel({ type: 'yt-popout-status', open: true });
        // Esta pestaña ya estaba abierta de antes (no se acaba de crear, no
        // recarga sola): si el panel se reinicio (F5) perdio todo su cache en
        // memoria (insignias, tier), y el scraper no vuelve a barrer los
        // mensajes ya presentes por su cuenta. Se le pide que lo haga ahora.
        // Si esto falla (ej. la extension se recargo en algun momento con
        // esta pestaña ya abierta: el content script viejo queda invalidado
        // y no escucha mas nada), se cierra esa pestaña muerta y se abre una
        // nueva en su lugar, en vez de quedar en silencio sin insignias.
        chrome.tabs.sendMessage(existing.id, { type: 'yt-request-rescan' })
          .then(() => resolve())
          .catch(() => {
            chrome.tabs.remove(existing.id).catch(() => {}).finally(() => createFreshPopout(url).then(resolve));
          });
        return;
      }
      createFreshPopout(url).then(resolve);
    });
  });
}

// Encadenadas una atras de otra (no en paralelo): si llegan dos avisos de
// "chat conectado" casi juntos -- ej. el panel abierto sin querer en dos
// pestañas a la vez, cada una detecta el directo por su cuenta y manda su
// propio aviso -- sin esto, el segundo chrome.tabs.query corria ANTES de
// que el chrome.tabs.create del primero terminara, no encontraba la
// pestaña recien creada, y abria una segunda de mas.
let popoutOpQueue = Promise.resolve();
function openOrFocusPopout(videoId) {
  popoutOpQueue = popoutOpQueue.then(() => openOrFocusPopoutNow(videoId)).catch(() => {});
}

function closeManagedPopout() {
  if (managedTabId == null) return;
  chrome.tabs.remove(managedTabId).catch(() => {});
  managedTabId = null;
  sendToPanel({ type: 'yt-popout-status', open: false });
}

// Si el streamer cierra la pestaña el mismo (en vez de usar "Desconectar"
// en el panel), el indicador tiene que enterarse igual.
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === managedTabId) {
    managedTabId = null;
    sendToPanel({ type: 'yt-popout-status', open: false });
  }
});

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg) return;

  if (msg.type === 'yt-tier' || msg.type === 'yt-message') {
    sendToPanel(msg);
    return;
  }

  if ((msg.type === 'yt-chat-connected' || msg.type === 'yt-request-open-popout') && msg.videoId) {
    openOrFocusPopout(msg.videoId);
    return;
  }

  if (msg.type === 'yt-chat-disconnected') {
    closeManagedPopout();
  }
});
