// Corre en la pagina del chat popout de YouTube (youtube.com/live_chat?v=...).
// Lee el chat directo del DOM (como hace Social Stream Ninja, ver
// github.com/steveseguin/social_stream/sources/youtube.js): sin esto, el
// panel solo puede leer por la API oficial (con ~2s de retraso y gastando
// cuota). Con la extension activa, los mensajes llegan instantaneos y sin
// tocar cuota, ademas de traer el tier real del miembro que la API no
// manda nunca en un mensaje normal.
let msgCounter = 0;

function getText(el) {
  if (!el) return '';
  return (el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
}

// Las fotos de avatar/badges de Google traen el tamaño incrustado en la URL
// (=s32-..., =w16-h16-...): el chat las pide chiquitas porque ahi se ven
// asi de chico, pero en el overlay se muestran mas grandes y quedan
// pixeladas. Pedir el mismo archivo en un tamaño mayor (mismo criterio que
// usa Social Stream Ninja) no cuesta nada extra, es el mismo CDN.
function upscaleGoogleImage(url) {
  if (!url) return url;
  return url
    .replace(/=s\d+(-|$)/, '=s256$1')
    .replace(/=w\d+-h\d+(-|$)/, '=w256-h256$1');
}

// Mismos selectores que usa Social Stream Ninja para el monto de un
// superchat/supersticker (YouTube no siempre usa el mismo id/clase).
function getDonationAmount(msgEl) {
  const selectors = ['#purchase-amount', '#purchase-amount-chip', "[id*='purchase-amount']", "[class*='purchase-amount']"];
  for (const sel of selectors) {
    const found = msgEl.querySelector(sel);
    const text = getText(found);
    if (text) return text;
  }
  return '';
}

// La deteccion de insignias no es 100% estable entre layouts/idiomas de
// YouTube (a veces el atributo `type` dice "mod", a veces "moderator"; el
// dueño del canal a veces no trae `type` para nada). Por eso se combinan
// varias señales (atributo type, clases del nombre, alt/aria-label/title
// del propio icono de la insignia) en vez de confiar en una sola forma.
// yt-live-chat-author-badge-renderer es un custom element: su icono suele
// vivir en su Shadow DOM, que querySelector normal NO puede atravesar (por
// spec, da igual si el shadow root es "open"). Por eso el nombre/mensaje se
// leian bien (esos SI son luz/light DOM) pero la imagen de la insignia no
// aparecia nunca. deepQuery prueba primero luz DOM y despues el shadowRoot.
function deepQuery(el, selector) {
  if (!el) return null;
  // BFS por todo el arbol, cruzando cualquier shadow root abierto que
  // aparezca en el camino (puede haber mas de un nivel anidado).
  const queue = [el];
  while (queue.length) {
    const node = queue.shift();
    const found = node.querySelector ? node.querySelector(selector) : null;
    if (found) return found;
    const walker = node.querySelectorAll ? node.querySelectorAll('*') : [];
    walker.forEach((child) => {
      if (child.shadowRoot) queue.push(child.shadowRoot);
    });
    if (node.shadowRoot) queue.push(node.shadowRoot);
  }
  return null;
}

function detectBadges(msgEl, nameEl) {
  let isMod = false;
  let isOwner = false;
  let isMember = false;
  let isVerified = false;
  // El icono REAL de cada insignia (la imagen que YouTube ya muestra: la
  // estrellita de miembro, la llave de mod, el tilde de verificado) se
  // manda tal cual en vez de armar un chip de texto propio.
  const badgeImages = [];

  msgEl.querySelectorAll('yt-live-chat-author-badge-renderer').forEach((b) => {
    const icon = deepQuery(b, 'img, svg, yt-icon');
    const label = [
      b.getAttribute('type'),
      b.getAttribute('aria-label'),
      b.getAttribute('title'),
      icon && icon.getAttribute && icon.getAttribute('alt'),
      icon && icon.getAttribute && icon.getAttribute('aria-label'),
      b.className,
    ].filter(Boolean).join(' ').toLowerCase();
    const badgeIsOwner = /owner|broadcaster/.test(label);
    const badgeIsMod = !badgeIsOwner && /mod/.test(label); // despues de owner para no confundir "moderator" con nada raro
    const badgeIsMember = /member|sponsor/.test(label);
    if (badgeIsOwner) isOwner = true;
    if (badgeIsMod) isMod = true;
    if (badgeIsMember) isMember = true;
    if (/verif/.test(label)) isVerified = true;

    // Moderador y verificado son siempre el mismo icono en cualquier canal
    // (ya se guardaron una vez como archivo fijo, ver public/kick-badges/
    // yt-moderator.png / yt-verified.png), y "streamer" no tiene icono
    // propio: no hace falta scrapear su imagen del DOM. Solo el de miembro
    // cambia segun el canal, asi que es el unico que vale la pena sacar.
    if (!badgeIsMember) return;

    const img = deepQuery(b, 'img[src]');
    if (img && img.src) {
      badgeImages.push({ src: upscaleGoogleImage(img.src), alt: label || 'insignia' });
    }
  });

  const nameClass = (nameEl.className || '').toLowerCase();
  if (/owner|broadcaster/.test(nameClass)) isOwner = true;
  if (/moderator/.test(nameClass)) isMod = true;
  if (/member/.test(nameClass)) isMember = true;

  return { isMod, isOwner, isMember, isVerified, badgeImages };
}

// Los emojis (nativos o del canal) vienen como <img> dentro del mensaje;
// innerText los ignora por completo (se pierden). A veces el <img> no es
// hijo directo de #message sino que esta un nivel mas adentro (envuelto en
// un span/wrapper), por eso se recorre recursivamente en vez de mirar solo
// los hijos directos (mismo criterio que usa Social Stream Ninja en
// getAllContentNodes2). Cada imagen se guarda como token [yt-emoji:src:alt]
// para que admin.html la vuelva a dibujar como imagen (igual que los
// emotes de Kick, ver renderKickContent).
function extractNodeContent(node) {
  if (node.nodeType === Node.TEXT_NODE) return node.textContent || '';
  if (node.nodeType !== Node.ELEMENT_NODE) return '';

  if (node.tagName === 'IMG') {
    const src = node.currentSrc || node.getAttribute('src') || node.getAttribute('data-src') || '';
    const alt = node.getAttribute('alt') || '';
    return src ? `[yt-emoji:${encodeURIComponent(src)}:${encodeURIComponent(alt)}]` : alt;
  }
  // Elemento contenedor (span/div envolviendo el emoji, etc): si tiene
  // hijos, se sigue bajando; si es una hoja sin imagen, se cae al texto
  // (ej. un shortcode oculto para accesibilidad).
  if (node.childNodes.length) {
    let inner = '';
    node.childNodes.forEach((child) => { inner += extractNodeContent(child); });
    return inner;
  }
  return node.textContent || '';
}

function extractMessageContent(messageEl) {
  if (!messageEl) return '';
  let out = '';
  messageEl.childNodes.forEach((node) => {
    out += extractNodeContent(node);
  });
  return out.trim();
}

function extractMessage(msgEl) {
  try {
    const nameEl = msgEl.querySelector('#author-name');
    if (!nameEl) return null;
    const name = getText(nameEl);
    if (!name) return null;

    const { isMod, isOwner, isMember, isVerified, badgeImages } = detectBadges(msgEl, nameEl);

    // El tier real (ej. "Miembro (6 meses)") vive en el aria-label del
    // nombre, y solo tiene sentido leerlo cuando es miembro.
    const tier = isMember ? (nameEl.getAttribute('aria-label') || '') : '';

    let avatar = '';
    try {
      const img = msgEl.querySelector('#img[src], #author-photo img[src]');
      if (img) avatar = upscaleGoogleImage(img.src);
    } catch { /* sin avatar */ }

    const messageEl = msgEl.querySelector('#message');
    const message = extractMessageContent(messageEl);

    const tag = msgEl.tagName;
    const isPaid = tag === 'YT-LIVE-CHAT-PAID-MESSAGE-RENDERER' || tag === 'YT-LIVE-CHAT-PAID-STICKER-RENDERER';
    const isMembership = tag === 'YT-LIVE-CHAT-MEMBERSHIP-ITEM-RENDERER';
    const amountText = isPaid ? getDonationAmount(msgEl) : '';

    let kind = 'text';
    if (tag === 'YT-LIVE-CHAT-PAID-MESSAGE-RENDERER') kind = 'superChat';
    else if (tag === 'YT-LIVE-CHAT-PAID-STICKER-RENDERER') kind = 'superSticker';
    else if (isMembership) kind = 'membership';

    if (!msgEl.dataset.yapeMid) msgEl.dataset.yapeMid = String(++msgCounter);
    // YouTube ya trae su propio id estable en el elemento (el mismo que usa
    // internamente para no re-renderizar un mensaje que ya esta en el DOM):
    // usarlo si esta, en vez del contador propio, evita duplicar un
    // superchat cuando esta pestaña se recarga/reabre a mitad de directo (el
    // contador arranca de nuevo en 0 en una pestaña nueva, pero el id nativo
    // de YouTube para ESE mismo mensaje es siempre el mismo). El contador
    // sigue como respaldo por si algun layout de YouTube no trae id.
    const msgId = msgEl.id ? `yt-${msgEl.id}` : `dom-${msgEl.dataset.yapeMid}`;

    return {
      type: 'yt-message',
      msgId,
      kind,
      name,
      avatar,
      message: isMembership ? getText(msgEl.querySelector('#header-subtext, #primary-text')) : message,
      amountText,
      isMod,
      isOwner,
      isMember,
      isVerified,
      tier,
      badgeImages,
      publishedAt: Date.now(),
    };
  } catch (err) {
    console.error('[yape-alert-ext]', err);
    return null;
  }
}

function handleElement(msgEl) {
  if (msgEl.dataset.yapeSent === '1') return; // ya se mando, no duplicar
  const data = extractMessage(msgEl);
  if (!data) return;
  msgEl.dataset.yapeSent = '1';
  chrome.runtime.sendMessage(data);
}

function scanExisting() {
  document
    .querySelectorAll('yt-live-chat-text-message-renderer, yt-live-chat-paid-message-renderer, yt-live-chat-paid-sticker-renderer, yt-live-chat-membership-item-renderer')
    .forEach(handleElement);
}

// Si el panel se recarga (F5) mientras esta pestaña del chat ya estaba
// abierta de antes, esta pestaña NO se recarga (background.js encuentra la
// existente y no crea una nueva), asi que el MutationObserver no vuelve a
// disparar para los mensajes ya presentes: el panel recien reiniciado se
// queda sin insignias hasta que llegue un mensaje totalmente nuevo.
// background.js pide este reescaneo justo en ese caso. Se manda solo el
// dato liviano de insignia (yt-tier), no el mensaje completo de nuevo, para
// no duplicar el chat del panel ni re-insertar superchats ya guardados.
function rescanBadgesOnly() {
  document
    .querySelectorAll('yt-live-chat-text-message-renderer, yt-live-chat-paid-message-renderer, yt-live-chat-paid-sticker-renderer, yt-live-chat-membership-item-renderer')
    .forEach((msgEl) => {
      const nameEl = msgEl.querySelector('#author-name');
      if (!nameEl) return;
      const name = getText(nameEl);
      if (!name) return;
      const { isMod, isOwner, isMember, isVerified, badgeImages } = detectBadges(msgEl, nameEl);
      const tier = isMember ? (nameEl.getAttribute('aria-label') || '') : '';
      chrome.runtime.sendMessage({ type: 'yt-tier', name, tier, isMod, isOwner, isMember, isVerified, badgeImages });
    });
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'yt-request-rescan') rescanBadgesOnly();
});

const observer = new MutationObserver((mutations) => {
  for (const m of mutations) {
    m.addedNodes.forEach((node) => {
      if (node.nodeType !== 1) return;
      const tag = node.tagName;
      if (
        tag === 'YT-LIVE-CHAT-TEXT-MESSAGE-RENDERER' ||
        tag === 'YT-LIVE-CHAT-PAID-MESSAGE-RENDERER' ||
        tag === 'YT-LIVE-CHAT-PAID-STICKER-RENDERER' ||
        tag === 'YT-LIVE-CHAT-MEMBERSHIP-ITEM-RENDERER'
      ) {
        handleElement(node);
      }
    });
  }
});

observer.observe(document.body, { childList: true, subtree: true });
scanExisting();
