# Extensión: tier real de miembros de YouTube

La API oficial de YouTube no manda el tier/nivel de un miembro en un mensaje normal de chat (solo en los mensajes de "se hizo miembro" o "aniversario"). Esta extensión lee esa info directamente de la página del chat en vivo de YouTube y se la pasa al panel de Yape Alert.

**Es opcional.** Sin esta extensión, el panel funciona exactamente igual, solo que el badge de miembro sale genérico ("MIEMBRO") en vez de con el tier real.

## Instalación (una sola vez)

1. Abrí Chrome (o Edge/Brave, cualquier navegador basado en Chromium) y andá a `chrome://extensions`.
2. Activá **"Modo desarrollador"** (interruptor arriba a la derecha).
3. Click en **"Cargar descomprimida"**.
4. Seleccioná esta carpeta (`browser-extension`).
5. Listo, ya está instalada. No hace falta reinstalarla cada vez, solo si Chrome la desactiva sola (puede pasar después de reiniciar el navegador si "Modo desarrollador" se desactivó).

## Cómo usarla en cada directo

Nada especial: abrí el panel de Yape Alert (`admin.html`) como siempre y conectate al chat de YouTube (a mano o por detección automática de canal). Con la extensión instalada, en cuanto el panel se conecta, ella misma abre en segundo plano la pestaña del chat popout de YouTube (no te va a robar el foco ni molestar), y la cierra sola cuando el panel se desconecta. No hace falta que abras ni cierres nada vos.

Mientras esa pestaña siga abierta, el panel va a mostrar el tier real de cada miembro que escriba. Si por algún motivo la cerrás vos manualmente, el panel sigue funcionando normal, solo vuelve al badge genérico.
