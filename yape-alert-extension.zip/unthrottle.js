// Esta pestaña la abre background.js siempre de fondo (active:false, ver
// createFreshPopout) para no robarle el foco al streamer. El problema es
// que YouTube usa la Page Visibility API para bajarle el ritmo a su propio
// chat en vivo cuando la pestaña no esta al frente: los mensajes se quedan
// en cola y entran todos de golpe recien cuando la pestaña pasa a estar
// visible (por eso "cuando minimizo va lento y cuando abro entran de
// golpe"). Como esta pestaña esta pensada para vivir siempre de fondo, se
// le miente a YouTube: se le hace creer que SIEMPRE esta visible y con
// foco, para que nunca frene su propio ritmo de renderizado.
// Tiene que correr en document_start (antes que el codigo de YouTube lea
// document.hidden por primera vez) y en el "MAIN world" (no en el mundo
// aislado del content script): document.hidden es un getter nativo en
// Document.prototype, y aunque el DOM se comparte entre mundos, algunos
// navegadores cachean el descriptor original antes de que un mundo aislado
// pueda pisarlo. Corriendo en MAIN world no hay ninguna duda de que se
// pisa antes de que el propio codigo de YouTube arranque.
(() => {
  try {
    Object.defineProperty(Document.prototype, 'hidden', { get: () => false, configurable: true });
    Object.defineProperty(Document.prototype, 'visibilityState', { get: () => 'visible', configurable: true });
    Object.defineProperty(Document.prototype, 'webkitHidden', { get: () => false, configurable: true });
    Object.defineProperty(Document.prototype, 'webkitVisibilityState', { get: () => 'visible', configurable: true });
    document.hasFocus = () => true;
  } catch { /* si el navegador no deja redefinir esto, sigue lento pero funciona */ }

  // Si YouTube igual escucha el evento (en vez de solo consultar
  // document.hidden), se lo cortamos antes de que le llegue.
  const blockedEvents = ['visibilitychange', 'webkitvisibilitychange'];
  const stop = (e) => { e.stopImmediatePropagation(); };
  blockedEvents.forEach((type) => document.addEventListener(type, stop, true));
})();

// Lo de arriba (pisar document.hidden) solo engaña al codigo de YouTube
// que LEE esa propiedad. No alcanza: Chrome tiene su propio freno interno
// para pestañas de fondo (le baja la prioridad a los timers/websockets de
// CUALQUIER pestaña que no se este pintando en pantalla, sin mirar
// document.hidden para nada, es una decision del navegador, no de la
// pagina) y ESE es el que hace que el chat vaya lento cuando esta
// minimizado. Chrome exceptua de este freno a las pestañas que estan
// reproduciendo audio (para que no corten musica/radio de fondo). El
// truco, entonces, es hacer sonar un tono looping casi inaudible (bajito
// a proposito, no en 0: un audio totalmente silencioso a veces no cuenta
// como "reproduciendo" para el detector de Chrome) para que esta pestaña
// quede en esa lista de excepciones y no se frene nunca.
(() => {
  const SILENT_TONE_DATA_URI = 'data:audio/wav;base64,UklGRsQPAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YaAPAAAAAAEAAwAEAAYABwAIAAoACwANAA4ADwARABIAEwAVABYAFwAZABoAGwAcAB4AHwAgACEAIwAkACUAJgAnACgAKQAqACsALAAtAC4ALwAwADEAMQAyADMANAA0ADUANgA2ADcANwA4ADgAOQA5ADoAOgA6ADsAOwA7ADsAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADsAOwA7ADsAOgA6ADkAOQA5ADgAOAA3ADYANgA1ADUANAAzADIAMgAxADAALwAuAC0ALAArACoAKQAoACcAJgAlACQAIwAiACEAHwAeAB0AHAAaABkAGAAXABUAFAATABEAEAAOAA0ADAAKAAkACAAGAAUAAwACAAAA///+//z/+//5//j/9//1//T/8v/x//D/7v/t/+z/6v/p/+j/5v/l/+T/4//h/+D/3//e/93/3P/a/9n/2P/X/9b/1f/U/9P/0v/R/9H/0P/P/87/zf/N/8z/y//L/8r/yf/J/8j/yP/H/8f/xv/G/8b/xf/F/8X/xf/E/8T/xP/E/8T/xP/E/8T/xP/E/8T/xf/F/8X/xf/G/8b/xv/H/8f/yP/I/8n/yf/K/8v/y//M/83/zf/O/8//0P/R/9H/0v/T/9T/1f/W/9f/2P/Z/9r/3P/d/97/3//g/+H/4//k/+X/5v/o/+n/6v/s/+3/7v/w//H/8v/0//X/9//4//n/+//8//7///8AAAIAAwAFAAYACAAJAAoADAANAA4AEAARABMAFAAVABcAGAAZABoAHAAdAB4AHwAhACIAIwAkACUAJgAnACgAKQAqACsALAAtAC4ALwAwADEAMgAyADMANAA1ADUANgA2ADcAOAA4ADkAOQA5ADoAOgA7ADsAOwA7ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA7ADsAOwA7ADoAOgA6ADkAOQA4ADgANwA3ADYANgA1ADQANAAzADIAMQAxADAALwAuAC0ALAArACoAKQAoACcAJgAlACQAIwAhACAAHwAeABwAGwAaABkAFwAWABUAEwASABEADwAOAA0ACwAKAAgABwAGAAQAAwABAAAA///9//z/+v/5//j/9v/1//P/8v/x/+//7v/t/+v/6v/p/+f/5v/l/+T/4v/h/+D/3//d/9z/2//a/9n/2P/X/9b/1f/U/9P/0v/R/9D/z//P/87/zf/M/8z/y//K/8r/yf/J/8j/yP/H/8f/xv/G/8b/xf/F/8X/xf/E/8T/xP/E/8T/xP/E/8T/xP/E/8T/xf/F/8X/xf/G/8b/x//H/8f/yP/I/8n/yv/K/8v/y//M/83/zv/O/8//0P/R/9L/0//U/9X/1v/X/9j/2f/a/9v/3P/d/97/3//h/+L/4//k/+b/5//o/+n/6//s/+3/7//w//L/8//0//b/9//4//r/+//9//7/AAABAAIABAAFAAcACAAJAAsADAAOAA8AEAASABMAFAAWABcAGAAaABsAHAAdAB8AIAAhACIAIwAkACYAJwAoACkAKgArACwALQAuAC8ALwAwADEAMgAzADMANAA1ADUANgA3ADcAOAA4ADkAOQA6ADoAOgA7ADsAOwA7ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA7ADsAOwA7ADoAOgA6ADkAOQA4ADgANwA3ADYANQA1ADQAMwAzADIAMQAwAC8ALwAuAC0ALAArACoAKQAoACcAJgAkACMAIgAhACAAHwAdABwAGwAaABgAFwAWABQAEwASABAADwAOAAwACwAJAAgABwAFAAQAAgABAAAA/v/9//v/+v/4//f/9v/0//P/8v/w/+//7f/s/+v/6f/o/+f/5v/k/+P/4v/h/9//3v/d/9z/2//a/9n/2P/X/9b/1f/U/9P/0v/R/9D/z//O/87/zf/M/8v/y//K/8r/yf/I/8j/x//H/8f/xv/G/8X/xf/F/8X/xP/E/8T/xP/E/8T/xP/E/8T/xP/E/8X/xf/F/8X/xv/G/8b/x//H/8j/yP/J/8n/yv/K/8v/zP/M/83/zv/P/8//0P/R/9L/0//U/9X/1v/X/9j/2f/a/9v/3P/d/9//4P/h/+L/5P/l/+b/5//p/+r/6//t/+7/7//x//L/8//1//b/+P/5//r//P/9////AAABAAMABAAGAAcACAAKAAsADQAOAA8AEQASABMAFQAWABcAGQAaABsAHAAeAB8AIAAhACMAJAAlACYAJwAoACkAKgArACwALQAuAC8AMAAxADEAMgAzADQANAA1ADYANgA3ADcAOAA4ADkAOQA6ADoAOgA7ADsAOwA7ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA7ADsAOwA7ADoAOgA5ADkAOQA4ADgANwA2ADYANQA1ADQAMwAyADIAMQAwAC8ALgAtACwAKwAqACkAKAAnACYAJQAkACMAIgAhAB8AHgAdABwAGgAZABgAFwAVABQAEwARABAADgANAAwACgAJAAgABgAFAAMAAgAAAP///v/8//v/+f/4//f/9f/0//L/8f/w/+7/7f/s/+r/6f/o/+b/5f/k/+P/4f/g/9//3v/d/9z/2v/Z/9j/1//W/9X/1P/T/9L/0f/R/9D/z//O/83/zf/M/8v/y//K/8n/yf/I/8j/x//H/8b/xv/G/8X/xf/F/8X/xP/E/8T/xP/E/8T/xP/E/8T/xP/E/8X/xf/F/8X/xv/G/8b/x//H/8j/yP/J/8n/yv/L/8v/zP/N/83/zv/P/9D/0f/R/9L/0//U/9X/1v/X/9j/2f/a/9z/3f/e/9//4P/h/+P/5P/l/+b/6P/p/+r/7P/t/+7/8P/x//L/9P/1//f/+P/5//v//P/+////AAACAAMABQAGAAgACQAKAAwADQAOABAAEQATABQAFQAXABgAGQAaABwAHQAeAB8AIQAiACMAJAAlACYAJwAoACkAKgArACwALQAuAC8AMAAxADIAMgAzADQANQA1ADYANgA3ADgAOAA5ADkAOQA6ADoAOwA7ADsAOwA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAOwA7ADsAOwA6ADoAOgA5ADkAOAA4ADcANwA2ADYANQA0ADQAMwAyADEAMQAwAC8ALgAtACwAKwAqACkAKAAnACYAJQAkACMAIQAgAB8AHgAcABsAGgAZABcAFgAVABMAEgARAA8ADgANAAsACgAIAAcABgAEAAMAAQAAAP///f/8//r/+f/4//b/9f/z//L/8f/v/+7/7f/r/+r/6f/n/+b/5f/k/+L/4f/g/9//3f/c/9v/2v/Z/9j/1//W/9X/1P/T/9L/0f/Q/8//z//O/83/zP/M/8v/yv/K/8n/yf/I/8j/x//H/8b/xv/G/8X/xf/F/8X/xP/E/8T/xP/E/8T/xP/E/8T/xP/E/8X/xf/F/8X/xv/G/8f/x//H/8j/yP/J/8r/yv/L/8v/zP/N/87/zv/P/9D/0f/S/9P/1P/V/9b/1//Y/9n/2v/b/9z/3f/e/9//4f/i/+P/5P/m/+f/6P/p/+v/7P/t/+//8P/y//P/9P/2//f/+P/6//v//f/+/wAAAQACAAQABQAHAAgACQALAAwADgAPABAAEgATABQAFgAXABgAGgAbABwAHQAfACAAIQAiACMAJAAmACcAKAApACoAKwAsAC0ALgAvAC8AMAAxADIAMwAzADQANQA1ADYANwA3ADgAOAA5ADkAOgA6ADoAOwA7ADsAOwA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAOwA7ADsAOwA6ADoAOgA5ADkAOAA4ADcANwA2ADUANQA0ADMAMwAyADEAMAAvAC8ALgAtACwAKwAqACkAKAAnACYAJAAjACIAIQAgAB8AHQAcABsAGgAYABcAFgAUABMAEgAQAA8ADgAMAAsACQAIAAcABQAEAAIAAQAAAP7//f/7//r/+P/3//b/9P/z//L/8P/v/+3/7P/r/+n/6P/n/+b/5P/j/+L/4f/f/97/3f/c/9v/2v/Z/9j/1//W/9X/1P/T/9L/0f/Q/8//zv/O/83/zP/L/8v/yv/K/8n/yP/I/8f/x//H/8b/xv/F/8X/xf/F/8T/xP/E/8T/xP/E/8T/xP/E/8T/xP/F/8X/xf/F/8b/xv/G/8f/x//I/8j/yf/J/8r/yv/L/8z/zP/N/87/z//P/9D/0f/S/9P/1P/V/9b/1//Y/9n/2v/b/9z/3f/f/+D/4f/i/+T/5f/m/+f/6f/q/+v/7f/u/+//8f/y//P/9f/2//j/+f/6//z//f///wAAAQADAAQABgAHAAgACgALAA0ADgAPABEAEgATABUAFgAXABkAGgAbABwAHgAfACAAIQAjACQAJQAmACcAKAApACoAKwAsAC0ALgAvADAAMQAxADIAMwA0ADQANQA2ADYANwA3ADgAOAA5ADkAOgA6ADoAOwA7ADsAOwA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAOwA7ADsAOwA6ADoAOQA5ADkAOAA4ADcANgA2ADUANQA0ADMAMgAyADEAMAAvAC4ALQAsACsAKgApACgAJwAmACUAJAAjACIAIQAfAB4AHQAcABoAGQAYABcAFQAUABMAEQAQAA4ADQAMAAoACQAIAAYABQADAAIAAAD///7//P/7//n/+P/3//X/9P/y//H/8P/u/+3/7P/q/+n/6P/m/+X/5P/j/+H/4P/f/97/3f/c/9r/2f/Y/9f/1v/V/9T/0//S/9H/0f/Q/8//zv/N/83/zP/L/8v/yv/J/8n/yP/I/8f/x//G/8b/xv/F/8X/xf/F/8T/xP/E/8T/xP/E/8T/xP/E/8T/xP/F/8X/xf/F/8b/xv/G/8f/x//I/8j/yf/J/8r/y//L/8z/zf/N/87/z//Q/9H/0f/S/9P/1P/V/9b/1//Y/9n/2v/c/93/3v/f/+D/4f/j/+T/5f/m/+j/6f/q/+z/7f/u//D/8f/y//T/9f/3//j/+f/7//z//v///wAAAgADAAUABgAIAAkACgAMAA0ADgAQABEAEwAUABUAFwAYABkAGgAcAB0AHgAfACEAIgAjACQAJQAmACcAKAApACoAKwAsAC0ALgAvADAAMQAyADIAMwA0ADUANQA2ADYANwA4ADgAOQA5ADkAOgA6ADsAOwA7ADsAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADsAOwA7ADsAOgA6ADoAOQA5ADgAOAA3ADcANgA2ADUANAA0ADMAMgAxADEAMAAvAC4ALQAsACsAKgApACgAJwAmACUAJAAjACEAIAAfAB4AHAAbABoAGQAXABYAFQATABIAEQAPAA4ADQALAAoACAAHAAYABAADAAEA';

  function startKeepAliveAudio() {
    try {
      const audio = new Audio(SILENT_TONE_DATA_URI);
      audio.loop = true;
      audio.volume = 0.03; // apenas perceptible: alcanza para que Chrome la cuente como "reproduciendo"
      const play = () => audio.play().catch(() => {});
      play();
      // youtube.com casi siempre permite autoplay con sonido (motor/engagement
      // alto), pero por si el navegador lo bloquea la primera vez, se
      // reintenta en cuanto haya cualquier interaccion con la pagina.
      document.addEventListener('click', play, { once: true, capture: true });
      document.addEventListener('visibilitychange', play, { capture: true });
    } catch { /* si Audio no esta disponible, sigue lento pero funciona */ }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startKeepAliveAudio, { once: true });
  } else {
    startKeepAliveAudio();
  }
})();
